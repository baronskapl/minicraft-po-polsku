$ErrorActionPreference = "Stop"

$projectDir = $PSScriptRoot
$classesDir = Join-Path $projectDir "build\classes"
$jarFile = Join-Path (Split-Path $projectDir -Parent) "gra.jar"
$iconFile = Join-Path (Split-Path $projectDir -Parent) "ikonka.ico"
$javac = "D:\minicraft\java\bin\javac.exe"
$jar = "D:\minicraft\java\bin\jar.exe"

if (-not (Test-Path $javac)) {
   $javac = "javac"
}
if (-not (Test-Path $jar)) {
   $jar = "jar"
}
if (-not (Test-Path (Join-Path $projectDir "icons.png"))) {
   throw "Missing required resource: icons.png"
}
if (-not (Test-Path $iconFile)) {
   throw "Missing application icon: $iconFile"
}

if (Test-Path $classesDir) {
   Remove-Item $classesDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $classesDir | Out-Null
$javaFiles = Get-ChildItem -Path (Join-Path $projectDir "com") -Recurse -Filter *.java | Select-Object -ExpandProperty FullName
& $javac -encoding UTF-8 -d $classesDir $javaFiles
if ($LASTEXITCODE -ne 0) {
   throw "Java compilation failed with exit code $LASTEXITCODE"
}

Copy-Item (Join-Path $projectDir "icons.png") $classesDir
Get-ChildItem -Path $projectDir -Filter *.wav | Copy-Item -Destination $classesDir
$languageDir = Join-Path $projectDir "lang"
if (Test-Path $languageDir) {
   $languageOutputDir = Join-Path $classesDir "lang"
   New-Item -ItemType Directory -Force -Path $languageOutputDir | Out-Null
   Copy-Item (Join-Path $languageDir "*") $languageOutputDir -Recurse -Force
}
Add-Type -AssemblyName System.Drawing
$icon = New-Object System.Drawing.Icon($iconFile)
$iconBitmap = $icon.ToBitmap()
$iconBitmap.Save((Join-Path $classesDir "app-icon.png"), [System.Drawing.Imaging.ImageFormat]::Png)
$iconBitmap.Dispose()
$icon.Dispose()

& $jar cfe $jarFile com.mojang.ld22.Game -C $classesDir .
if ($LASTEXITCODE -ne 0) {
   throw "JAR packaging failed with exit code $LASTEXITCODE"
}

Write-Host "Created $jarFile"
