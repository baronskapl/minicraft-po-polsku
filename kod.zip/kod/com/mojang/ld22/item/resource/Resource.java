package com.mojang.ld22.item.resource;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.i18n.Lang;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import java.util.Locale;

public class Resource {
   public static Resource wood = new Resource("Wood", 129, Color.get(-1, 200, 531, 430));
   public static Resource stone = new Resource("Stone", 130, Color.get(-1, 111, 333, 555));
   public static Resource flower;
   public static Resource acorn;
   public static Resource dirt;
   public static Resource sand;
   public static Resource cactusFlower;
   public static Resource seeds;
   public static Resource wheat;
   public static Resource bread;
   public static Resource apple;
   public static Resource coal;
   public static Resource ironOre;
   public static Resource goldOre;
   public static Resource ironIngot;
   public static Resource goldIngot;
   public static Resource slime;
   public static Resource glass;
   public static Resource cloth;
   public static Resource cloud;
   public static Resource gem;
   public final String name;
   public final int sprite;
   public final int color;

   static {
      flower = new PlantableResource("Flower", 128, Color.get(-1, 10, 444, 330), Tile.flower, new Tile[]{Tile.grass});
      acorn = new PlantableResource("Acorn", 131, Color.get(-1, 100, 531, 320), Tile.treeSapling, new Tile[]{Tile.grass});
      dirt = new PlantableResource("Dirt", 130, Color.get(-1, 100, 322, 432), Tile.dirt, new Tile[]{Tile.hole, Tile.water, Tile.lava});
      sand = new PlantableResource("Sand", 130, Color.get(-1, 110, 440, 550), Tile.sand, new Tile[]{Tile.grass, Tile.dirt});
      cactusFlower = new PlantableResource("Cactus", 132, Color.get(-1, 10, 40, 50), Tile.cactusSapling, new Tile[]{Tile.sand});
      seeds = new PlantableResource("Seeds", 133, Color.get(-1, 10, 40, 50), Tile.wheat, new Tile[]{Tile.farmland});
      wheat = new Resource("Wheat", 134, Color.get(-1, 110, 330, 550));
      bread = new FoodResource("Bread", 136, Color.get(-1, 110, 330, 550), 2, 5);
      apple = new FoodResource("Apple", 137, Color.get(-1, 100, 300, 500), 1, 5);
      coal = new Resource("COAL", 138, Color.get(-1, 0, 111, 111));
      ironOre = new Resource("I.ORE", 138, Color.get(-1, 100, 322, 544));
      goldOre = new Resource("G.ORE", 138, Color.get(-1, 110, 440, 553));
      ironIngot = new Resource("IRON", 139, Color.get(-1, 100, 322, 544));
      goldIngot = new Resource("GOLD", 139, Color.get(-1, 110, 330, 553));
      slime = new Resource("SLIME", 138, Color.get(-1, 10, 30, 50));
      glass = new Resource("glass", 140, Color.get(-1, 555, 555, 555));
      cloth = new Resource("cloth", 129, Color.get(-1, 25, 252, 141));
      cloud = new PlantableResource("cloud", 130, Color.get(-1, 222, 555, 444), Tile.cloud, new Tile[]{Tile.infiniteFall});
      gem = new Resource("gem", 141, Color.get(-1, 101, 404, 545));
   }

   public Resource(String name, int sprite, int color) {
      if (name.length() > 6) {
         throw new RuntimeException("Name cannot be longer than six characters!");
      } else {
         this.name = name;
         this.sprite = sprite;
         this.color = color;
      }
   }

   public String getDisplayName() {
      String key = "I.ORE".equalsIgnoreCase(this.name) ? "resource.iron_ore" : "G.ORE".equalsIgnoreCase(this.name) ? "resource.gold_ore" : "resource." + this.name.toLowerCase(Locale.ENGLISH);
      return Lang.get(key);
   }

   public boolean interactOn(Tile tile, Level level, int xt, int yt, Player player, int attackDir) {
      return false;
   }
}
