package com.mojang.ld22.item;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.i18n.Lang;
import java.util.Random;

public class ToolItem extends Item {
   private Random random = new Random();
   public static final int MAX_LEVEL = 5;
   public static final int[] LEVEL_COLORS = new int[]{Color.get(-1, 100, 321, 431), Color.get(-1, 100, 321, 111), Color.get(-1, 100, 321, 555), Color.get(-1, 100, 321, 550), Color.get(-1, 100, 321, 45)};
   public ToolType type;
   public int level = 0;

   public ToolItem(ToolType type, int level) {
      this.type = type;
      this.level = level;
   }

   public int getColor() {
      return LEVEL_COLORS[this.level];
   }

   public int getSprite() {
      return this.type.sprite + 160;
   }

   public void renderIcon(Screen screen, int x, int y) {
      screen.render(x, y, this.getSprite(), this.getColor(), 0);
   }

   public void renderInventory(Screen screen, int x, int y) {
      screen.render(x, y, this.getSprite(), this.getColor(), 0);
      Font.draw(this.getName(), screen, x + 8, y, Color.get(-1, 555, 555, 555));
   }

   public String getName() {
      String gender = this.type.feminine ? "f" : "m";
      String levelName = Lang.get("tool.level." + this.level + "." + gender);
      return Lang.get("tool.name", levelName, this.type.getDisplayName());
   }

   public void onTake(ItemEntity itemEntity) {
   }

   public boolean canAttack() {
      return true;
   }

   public int getAttackDamageBonus(Entity e) {
      if (this.type == ToolType.axe) {
         return (this.level + 1) * 2 + this.random.nextInt(4);
      } else {
         return this.type == ToolType.sword ? (this.level + 1) * 3 + this.random.nextInt(2 + this.level * this.level * 2) : 1;
      }
   }

   public boolean matches(Item item) {
      if (item instanceof ToolItem) {
         ToolItem other = (ToolItem)item;
         if (other.type != this.type) {
            return false;
         } else {
            return other.level == this.level;
         }
      } else {
         return false;
      }
   }
}
