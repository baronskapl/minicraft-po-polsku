package com.mojang.ld22.item;

import com.mojang.ld22.i18n.Lang;

public class ToolType {
   public static ToolType shovel = new ToolType("Shvl", "shovel", 0, true);
   public static ToolType hoe = new ToolType("Hoe", "hoe", 1, true);
   public static ToolType sword = new ToolType("Swrd", "sword", 2, false);
   public static ToolType pickaxe = new ToolType("Pick", "pickaxe", 3, false);
   public static ToolType axe = new ToolType("Axe", "axe", 4, true);
   public final String name;
   public final String key;
   public final int sprite;
   public final boolean feminine;

   private ToolType(String name, String key, int sprite, boolean feminine) {
      this.name = name;
      this.key = key;
      this.sprite = sprite;
      this.feminine = feminine;
   }

   public String getDisplayName() {
      return Lang.get("tool.type." + this.key);
   }
}
