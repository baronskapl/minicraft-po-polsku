package com.mojang.ld22.entity;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.sound.Sound;

public class ItemEntity extends Entity {
   private int lifeTime;
   protected int walkDist = 0;
   protected int dir = 0;
   public int hurtTime = 0;
   protected int xKnockback;
   protected int yKnockback;
   public double xa;
   public double ya;
   public double za;
   public double xx;
   public double yy;
   public double zz;
   public Item item;
   private int time = 0;

   public ItemEntity(Item item, int x, int y) {
      this.item = item;
      this.xx = (double)(this.x = x);
      this.yy = (double)(this.y = y);
      this.xr = 3;
      this.yr = 3;
      this.zz = 2.0;
      this.xa = this.random.nextGaussian() * 0.3;
      this.ya = this.random.nextGaussian() * 0.2;
      this.za = (double)this.random.nextFloat() * 0.7 + 1.0;
      this.lifeTime = 600 + this.random.nextInt(60);
   }

   public void tick() {
      ++this.time;
      if (this.time >= this.lifeTime) {
         this.remove();
      } else {
         this.xx += this.xa;
         this.yy += this.ya;
         this.zz += this.za;
         if (this.zz < 0.0) {
            this.zz = 0.0;
            this.za *= -0.5;
            this.xa *= 0.6;
            this.ya *= 0.6;
         }

         this.za -= 0.15;
         int ox = this.x;
         int oy = this.y;
         int nx = (int)this.xx;
         int ny = (int)this.yy;
         int expectedx = nx - this.x;
         int expectedy = ny - this.y;
         this.move(nx - this.x, ny - this.y);
         int gotx = this.x - ox;
         int goty = this.y - oy;
         this.xx += (double)(gotx - expectedx);
         this.yy += (double)(goty - expectedy);
         if (this.hurtTime > 0) {
            --this.hurtTime;
         }

      }
   }

   public boolean isBlockableBy(Mob mob) {
      return false;
   }

   public void render(Screen screen) {
      if (this.time < this.lifeTime - 120 || this.time / 6 % 2 != 0) {
         screen.render(this.x - 4, this.y - 4, this.item.getSprite(), Color.get(-1, 0, 0, 0), 0);
         screen.render(this.x - 4, this.y - 4 - (int)this.zz, this.item.getSprite(), this.item.getColor(), 0);
      }
   }

   protected void touchedBy(Entity entity) {
      if (this.time > 30) {
         entity.touchItem(this);
      }

   }

   public void take(Player player) {
      Sound.pickup.play();
      ++player.score;
      this.item.onTake(this);
      this.remove();
   }
}
