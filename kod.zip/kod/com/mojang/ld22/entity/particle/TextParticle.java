package com.mojang.ld22.entity.particle;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class TextParticle extends Entity {
   private String msg;
   private int col;
   private int time = 0;
   public double xa;
   public double ya;
   public double za;
   public double xx;
   public double yy;
   public double zz;

   public TextParticle(String msg, int x, int y, int col) {
      this.msg = msg;
      this.x = x;
      this.y = y;
      this.col = col;
      this.xx = (double)x;
      this.yy = (double)y;
      this.zz = 2.0;
      this.xa = this.random.nextGaussian() * 0.3;
      this.ya = this.random.nextGaussian() * 0.2;
      this.za = (double)this.random.nextFloat() * 0.7 + 2.0;
   }

   public void tick() {
      ++this.time;
      if (this.time > 60) {
         this.remove();
      }

      this.xx += this.xa;
      this.yy += this.ya;
      this.zz += this.za;
      if (this.zz < 0.0) {
         this.zz = 0.0;
         this.za *= -0.5;
         this.xa *= 0.6;
         this.ya *= 0.6;
      }

      this.za -= 0.15;
      this.x = (int)this.xx;
      this.y = (int)this.yy;
   }

   public void render(Screen screen) {
      Font.draw(this.msg, screen, this.x - this.msg.length() * 4 + 1, this.y - (int)this.zz + 1, Color.get(-1, 0, 0, 0));
      Font.draw(this.msg, screen, this.x - this.msg.length() * 4, this.y - (int)this.zz, this.col);
   }
}
