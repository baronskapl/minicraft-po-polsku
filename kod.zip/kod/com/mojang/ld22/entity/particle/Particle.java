package com.mojang.ld22.entity.particle;

import com.mojang.ld22.entity.Entity;

public class Particle extends Entity {
   public void tick() {
   }
}
