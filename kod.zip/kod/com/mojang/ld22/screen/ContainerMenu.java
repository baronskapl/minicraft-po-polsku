package com.mojang.ld22.screen;

import com.mojang.ld22.entity.Inventory;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.i18n.Lang;
import com.mojang.ld22.item.Item;

public class ContainerMenu extends Menu {
   private Player player;
   private Inventory container;
   private int selected = 0;
   private String title;
   private int oSelected;
   private int window = 0;

   public ContainerMenu(Player player, String title, Inventory container) {
      this.player = player;
      this.title = title;
      this.container = container;
   }

   public void tick() {
      if (this.input.menu.clicked) {
         this.game.setMenu((Menu)null);
      }

      int tmp;
      if (this.input.left.clicked) {
         this.window = 0;
         tmp = this.selected;
         this.selected = this.oSelected;
         this.oSelected = tmp;
      }

      if (this.input.right.clicked) {
         this.window = 1;
         tmp = this.selected;
         this.selected = this.oSelected;
         this.oSelected = tmp;
      }

      Inventory i = this.window == 1 ? this.player.inventory : this.container;
      Inventory i2 = this.window == 0 ? this.player.inventory : this.container;
      int len = i.items.size();
      if (this.selected < 0) {
         this.selected = 0;
      }

      if (this.selected >= len) {
         this.selected = len - 1;
      }

      if (this.input.up.clicked) {
         --this.selected;
      }

      if (this.input.down.clicked) {
         ++this.selected;
      }

      if (len == 0) {
         this.selected = 0;
      }

      if (this.selected < 0) {
         this.selected += len;
      }

      if (this.selected >= len) {
         this.selected -= len;
      }

      if (this.input.attack.clicked && len > 0) {
         i2.add(this.oSelected, (Item)i.items.remove(this.selected));
         if (this.selected >= i.items.size()) {
            this.selected = i.items.size() - 1;
         }
      }

   }

   public void render(Screen screen) {
      int split = screen.w / 16;
      int right = screen.w / 8 - 1;
      int bottom = screen.h / 8 - 1;
      Font.renderFrame(screen, this.title, 1, 1, split - 1, bottom);
      this.renderItemList(screen, 1, 1, split - 1, bottom, this.container.items, this.window == 0 ? this.selected : -this.oSelected - 1);
      Font.renderFrame(screen, Lang.get("menu.inventory"), split + 1, 1, right, bottom);
      this.renderItemList(screen, split + 1, 1, right, bottom, this.player.inventory.items, this.window == 1 ? this.selected : -this.oSelected - 1);
   }
}
