package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.i18n.Lang;

public class AboutMenu extends Menu {
   private Menu parent;

   public AboutMenu(Menu parent) {
      this.parent = parent;
   }

   public void tick() {
      if (this.input.attack.clicked || this.input.menu.clicked) {
         this.game.setMenu(this.parent);
      }

   }

   public void render(Screen screen) {
      screen.clear(0);
      Font.draw(Lang.get("menu.about_title"), screen, 20, 8, Color.get(0, 555, 555, 555));
      Font.draw(Lang.get("menu.about_line_1"), screen, 4, 24, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_2"), screen, 4, 32, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_3"), screen, 4, 40, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_4"), screen, 4, 48, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_5"), screen, 4, 56, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_6"), screen, 4, 72, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_7"), screen, 4, 80, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_8"), screen, 4, 88, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_9"), screen, 4, 96, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_line_10"), screen, 4, 104, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.about_signature"), screen, 4, 112, Color.get(0, 333, 333, 333));
   }
}
