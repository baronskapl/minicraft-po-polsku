package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Screen;

public interface ListItem {
   void renderInventory(Screen var1, int var2, int var3);
}
