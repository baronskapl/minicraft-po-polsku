package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.i18n.Lang;

public class InstructionsMenu extends Menu {
   private Menu parent;

   public InstructionsMenu(Menu parent) {
      this.parent = parent;
   }

   public void tick() {
      if (this.input.attack.clicked || this.input.menu.clicked) {
         this.game.setMenu(this.parent);
      }

   }

   public void render(Screen screen) {
      screen.clear(0);
      Font.draw(Lang.get("menu.instructions_title"), screen, 36, 8, Color.get(0, 555, 555, 555));
      Font.draw(Lang.get("menu.instructions_1"), screen, 4, 24, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_2"), screen, 4, 32, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_3"), screen, 4, 40, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_4"), screen, 4, 48, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_5"), screen, 4, 56, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_6"), screen, 4, 64, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_7"), screen, 4, 72, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_8"), screen, 4, 80, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_9"), screen, 4, 88, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_10"), screen, 4, 96, Color.get(0, 333, 333, 333));
      Font.draw(Lang.get("menu.instructions_11"), screen, 4, 104, Color.get(0, 333, 333, 333));
   }
}
