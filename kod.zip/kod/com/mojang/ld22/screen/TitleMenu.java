package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.i18n.Lang;
import com.mojang.ld22.sound.Sound;

public class TitleMenu extends Menu {
   private int selected = 0;
   private static final int OPTION_COUNT = 4;

   private String getOption(int index) {
      switch (index) {
         case 0: return Lang.get("menu.start");
         case 1: return Lang.get("menu.how_to_play");
         case 2: return Lang.get("menu.about");
         default: return Lang.get("menu.language") + ": " + Lang.get("language.name");
      }
   }

   public void tick() {
      if (this.input.up.clicked) {
         --this.selected;
      }

      if (this.input.down.clicked) {
         ++this.selected;
      }

      if (this.selected < 0) {
         this.selected += OPTION_COUNT;
      }

      if (this.selected >= OPTION_COUNT) {
         this.selected -= OPTION_COUNT;
      }

      boolean confirm = this.input.attack.clicked || this.input.menu.clicked;
      if (this.selected == 3 && (this.input.left.clicked || this.input.right.clicked || confirm)) {
         Lang.toggleLanguage();
      } else if (confirm) {
         if (this.selected == 0) {
            Sound.test.play();
            this.game.resetGame();
            this.game.setMenu((Menu)null);
         }

         if (this.selected == 1) {
            this.game.setMenu(new InstructionsMenu(this));
         }

         if (this.selected == 2) {
            this.game.setMenu(new AboutMenu(this));
         }
      }

   }

   public void render(Screen screen) {
      screen.clear(0);
      int h = 2;
      int w = 13;
      int titleColor = Color.get(0, 8, 131, 551);
      int xo = (screen.w - w * 8) / 2;
      int yo = 24;

      int i;
      for(i = 0; i < h; ++i) {
         for(int x = 0; x < w; ++x) {
            screen.render(xo + x * 8, yo + i * 8, x + (i + 6) * 32, titleColor, 0);
         }
      }

      for(i = 0; i < OPTION_COUNT; ++i) {
         String msg = this.getOption(i);
         int col = Color.get(0, 222, 222, 222);
         if (i == this.selected) {
            msg = "> " + msg + " <";
            col = Color.get(0, 555, 555, 555);
         }

         Font.draw(msg, screen, (screen.w - msg.length() * 8) / 2, (8 + i) * 8, col);
      }

      Font.draw(Lang.get("menu.controls"), screen, 0, screen.h - 8, Color.get(0, 111, 111, 111));
   }
}
