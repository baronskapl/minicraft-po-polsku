package com.mojang.ld22.i18n;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Properties;

public class Lang {
   private static final String DEFAULT_LANG = "en";
   private static final Properties FALLBACK = new Properties();
   private static final Properties ACTIVE = new Properties();
   private static String currentLanguage = DEFAULT_LANG;

   static {
      loadProperties(FALLBACK, "/lang/en.properties");
      if (FALLBACK.isEmpty()) {
         loadPropertiesFromFile(FALLBACK, new File("lang/en.properties"));
      }
      setLanguage(System.getProperty("minicraft.lang", Locale.getDefault().getLanguage()));
   }

   public static void setLanguage(String language) {
      ACTIVE.clear();
      String code = language == null || language.trim().isEmpty() ? DEFAULT_LANG : language.trim().toLowerCase(Locale.ENGLISH);
      currentLanguage = code;
      loadProperties(ACTIVE, "/lang/" + code + ".properties");
      if (ACTIVE.isEmpty()) {
         loadPropertiesFromFile(ACTIVE, new File("lang/" + code + ".properties"));
      }
      if (!DEFAULT_LANG.equals(code)) {
         for (String key : FALLBACK.stringPropertyNames()) {
            if (!ACTIVE.containsKey(key)) {
               ACTIVE.setProperty(key, FALLBACK.getProperty(key));
            }
         }
      }
   }

   public static String getLanguage() {
      return currentLanguage;
   }

   public static void toggleLanguage() {
      setLanguage("pl".equals(currentLanguage) ? "en" : "pl");
   }

   public static String get(String key) {
      String value = ACTIVE.getProperty(key);
      if (value != null) {
         return value;
      }
      return FALLBACK.getProperty(key, key);
   }

   public static String get(String key, Object... args) {
      String value = get(key);
      if (args == null || args.length == 0) {
         return value;
      }

      for (int i = 0; i < args.length; ++i) {
         value = value.replace("{" + i + "}", String.valueOf(args[i]));
      }
      return value;
   }

   private static void loadProperties(Properties properties, String path) {
      InputStream in = Lang.class.getResourceAsStream(path);
      if (in == null) {
         return;
      }

      try {
         properties.load(new InputStreamReader(in, StandardCharsets.UTF_8));
      } catch (IOException e) {
         throw new RuntimeException("Failed to load language file: " + path, e);
      } finally {
         try {
            in.close();
         } catch (IOException ignored) {
         }
      }
   }

   private static void loadPropertiesFromFile(Properties properties, File file) {
      if (file == null || !file.exists()) {
         return;
      }

      Reader in = null;
      try {
         in = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);
         properties.load(in);
      } catch (IOException e) {
         throw new RuntimeException("Failed to load language file: " + file.getAbsolutePath(), e);
      } finally {
         if (in != null) {
            try {
               in.close();
            } catch (IOException ignored) {
            }
         }
      }
   }
}
