package com.mojang.ld22.level;

import com.mojang.ld22.entity.AirWizard;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.Slime;
import com.mojang.ld22.entity.Zombie;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.levelgen.LevelGen;
import com.mojang.ld22.level.tile.Tile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

@SuppressWarnings("unchecked")
public class Level {
   private Random random = new Random();
   public int w;
   public int h;
   public byte[] tiles;
   public byte[] data;
   public List<Entity>[] entitiesInTiles;
   public int grassColor = 141;
   public int dirtColor = 322;
   public int sandColor = 550;
   private int depth;
   public int monsterDensity = 8;
   public List<Entity> entities = new ArrayList<Entity>();
   private Comparator<Entity> spriteSorter = new Comparator<Entity>() {
      public int compare(Entity e0, Entity e1) {
         if (e1.y < e0.y) {
            return 1;
         } else {
            return e1.y > e0.y ? -1 : 0;
         }
      }
   };
   private List<Entity> rowSprites = new ArrayList<Entity>();
   public Player player;

   public Level(int w, int h, int level, Level parentLevel) {
      if (level < 0) {
         this.dirtColor = 222;
      }

      this.depth = level;
      this.w = w;
      this.h = h;
      if (level == 1) {
         this.dirtColor = 444;
      }

      byte[][] maps;
      if (level == 0) {
         maps = LevelGen.createAndValidateTopMap(w, h);
      } else if (level < 0) {
         maps = LevelGen.createAndValidateUndergroundMap(w, h, -level);
         this.monsterDensity = 4;
      } else {
         maps = LevelGen.createAndValidateSkyMap(w, h);
         this.monsterDensity = 4;
      }

      this.tiles = maps[0];
      this.data = maps[1];
      int y;
      if (parentLevel != null) {
         for(y = 0; y < h; ++y) {
            for(int x = 0; x < w; ++x) {
               if (parentLevel.getTile(x, y) == Tile.stairsDown) {
                  this.setTile(x, y, Tile.stairsUp, 0);
                  if (level == 0) {
                     this.setTile(x - 1, y, Tile.hardRock, 0);
                     this.setTile(x + 1, y, Tile.hardRock, 0);
                     this.setTile(x, y - 1, Tile.hardRock, 0);
                     this.setTile(x, y + 1, Tile.hardRock, 0);
                     this.setTile(x - 1, y - 1, Tile.hardRock, 0);
                     this.setTile(x - 1, y + 1, Tile.hardRock, 0);
                     this.setTile(x + 1, y - 1, Tile.hardRock, 0);
                     this.setTile(x + 1, y + 1, Tile.hardRock, 0);
                  } else {
                     this.setTile(x - 1, y, Tile.dirt, 0);
                     this.setTile(x + 1, y, Tile.dirt, 0);
                     this.setTile(x, y - 1, Tile.dirt, 0);
                     this.setTile(x, y + 1, Tile.dirt, 0);
                     this.setTile(x - 1, y - 1, Tile.dirt, 0);
                     this.setTile(x - 1, y + 1, Tile.dirt, 0);
                     this.setTile(x + 1, y - 1, Tile.dirt, 0);
                     this.setTile(x + 1, y + 1, Tile.dirt, 0);
                  }
               }
            }
         }
      }

      this.entitiesInTiles = new ArrayList[w * h];

      for(y = 0; y < w * h; ++y) {
         this.entitiesInTiles[y] = new ArrayList<Entity>();
      }

      if (level == 1) {
         AirWizard aw = new AirWizard();
         aw.x = w * 8;
         aw.y = h * 8;
         this.add(aw);
      }

   }

   public void renderBackground(Screen screen, int xScroll, int yScroll) {
      int xo = xScroll >> 4;
      int yo = yScroll >> 4;
      int w = screen.w + 15 >> 4;
      int h = screen.h + 15 >> 4;
      screen.setOffset(xScroll, yScroll);

      for(int y = yo; y <= h + yo; ++y) {
         for(int x = xo; x <= w + xo; ++x) {
            this.getTile(x, y).render(screen, this, x, y);
         }
      }

      screen.setOffset(0, 0);
   }

   public void renderSprites(Screen screen, int xScroll, int yScroll) {
      int xo = xScroll >> 4;
      int yo = yScroll >> 4;
      int w = screen.w + 15 >> 4;
      int h = screen.h + 15 >> 4;
      screen.setOffset(xScroll, yScroll);

      for(int y = yo; y <= h + yo; ++y) {
         for(int x = xo; x <= w + xo; ++x) {
            if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
               this.rowSprites.addAll(this.entitiesInTiles[x + y * this.w]);
            }
         }

         if (this.rowSprites.size() > 0) {
            this.sortAndRender(screen, this.rowSprites);
         }

         this.rowSprites.clear();
      }

      screen.setOffset(0, 0);
   }

   public void renderLight(Screen screen, int xScroll, int yScroll) {
      int xo = xScroll >> 4;
      int yo = yScroll >> 4;
      int w = screen.w + 15 >> 4;
      int h = screen.h + 15 >> 4;
      screen.setOffset(xScroll, yScroll);
      int r = 4;

      for(int y = yo - r; y <= h + yo + r; ++y) {
         for(int x = xo - r; x <= w + xo + r; ++x) {
            if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
               List<Entity> entities = this.entitiesInTiles[x + y * this.w];

               for(int i = 0; i < entities.size(); ++i) {
                  Entity e = entities.get(i);
                  int lightRadius = e.getLightRadius();
                  if (lightRadius > 0) {
                     screen.renderLight(e.x - 1, e.y - 4, lightRadius * 8);
                  }
               }

               int tileLight = this.getTile(x, y).getLightRadius(this, x, y);
               if (tileLight > 0) {
                  screen.renderLight(x * 16 + 8, y * 16 + 8, tileLight * 8);
               }
            }
         }
      }

      screen.setOffset(0, 0);
   }

   private void sortAndRender(Screen screen, List<Entity> list) {
      Collections.sort(list, this.spriteSorter);

      for(int i = 0; i < list.size(); ++i) {
         list.get(i).render(screen);
      }

   }

   public Tile getTile(int x, int y) {
      return x >= 0 && y >= 0 && x < this.w && y < this.h ? Tile.tiles[this.tiles[x + y * this.w]] : Tile.rock;
   }

   public void setTile(int x, int y, Tile t, int dataVal) {
      if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
         this.tiles[x + y * this.w] = t.id;
         this.data[x + y * this.w] = (byte)dataVal;
      }
   }

   public int getData(int x, int y) {
      return x >= 0 && y >= 0 && x < this.w && y < this.h ? this.data[x + y * this.w] & 255 : 0;
   }

   public void setData(int x, int y, int val) {
      if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
         this.data[x + y * this.w] = (byte)val;
      }
   }

   public void add(Entity entity) {
      if (entity instanceof Player) {
         this.player = (Player)entity;
      }

      entity.removed = false;
      this.entities.add(entity);
      entity.init(this);
      this.insertEntity(entity.x >> 4, entity.y >> 4, entity);
   }

   public void remove(Entity e) {
      this.entities.remove(e);
      int xto = e.x >> 4;
      int yto = e.y >> 4;
      this.removeEntity(xto, yto, e);
   }

   private void insertEntity(int x, int y, Entity e) {
      if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
         this.entitiesInTiles[x + y * this.w].add(e);
      }
   }

   private void removeEntity(int x, int y, Entity e) {
      if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
         this.entitiesInTiles[x + y * this.w].remove(e);
      }
   }

   public void trySpawn(int count) {
      for(int i = 0; i < count; ++i) {
         int minLevel = 1;
         int maxLevel = 1;
         if (this.depth < 0) {
            maxLevel = -this.depth + 1;
         }

         if (this.depth > 0) {
            maxLevel = 4;
            minLevel = 4;
         }

         int lvl = this.random.nextInt(maxLevel - minLevel + 1) + minLevel;
         Object mob;
         if (this.random.nextInt(2) == 0) {
            mob = new Slime(lvl);
         } else {
            mob = new Zombie(lvl);
         }

         if (((Mob)mob).findStartPos(this)) {
            this.add((Entity)mob);
         }
      }

   }

   public void tick() {
      this.trySpawn(1);

      int i;
      int xto;
      for(i = 0; i < this.w * this.h / 50; ++i) {
         int xt = this.random.nextInt(this.w);
         xto = this.random.nextInt(this.w);
         this.getTile(xt, xto).tick(this, xt, xto);
      }

      for(i = 0; i < this.entities.size(); ++i) {
         Entity e = (Entity)this.entities.get(i);
         xto = e.x >> 4;
         int yto = e.y >> 4;
         e.tick();
         if (e.removed) {
            this.entities.remove(i--);
            this.removeEntity(xto, yto, e);
         } else {
            int xt = e.x >> 4;
            int yt = e.y >> 4;
            if (xto != xt || yto != yt) {
               this.removeEntity(xto, yto, e);
               this.insertEntity(xt, yt, e);
            }
         }
      }

   }

   public List<Entity> getEntities(int x0, int y0, int x1, int y1) {
      List<Entity> result = new ArrayList<Entity>();
      int xt0 = (x0 >> 4) - 1;
      int yt0 = (y0 >> 4) - 1;
      int xt1 = (x1 >> 4) + 1;
      int yt1 = (y1 >> 4) + 1;

      for(int y = yt0; y <= yt1; ++y) {
         for(int x = xt0; x <= xt1; ++x) {
            if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
               List<Entity> entities = this.entitiesInTiles[x + y * this.w];

               for(int i = 0; i < entities.size(); ++i) {
                  Entity e = entities.get(i);
                  if (e.intersects(x0, y0, x1, y1)) {
                     result.add(e);
                  }
               }
            }
         }
      }

      return result;
   }
}
