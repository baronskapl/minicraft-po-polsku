package com.mojang.ld22.level.levelgen;

import com.mojang.ld22.level.tile.Tile;
import java.awt.Component;
import java.awt.image.BufferedImage;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class LevelGen {
   private static final Random random = new Random();
   public double[] values;
   private int w;
   private int h;

   public LevelGen(int w, int h, int featureSize) {
      this.w = w;
      this.h = h;
      this.values = new double[w * h];

      int stepSize;
      for(stepSize = 0; stepSize < w; stepSize += featureSize) {
         for(int x = 0; x < w; x += featureSize) {
            this.setSample(x, stepSize, (double)(random.nextFloat() * 2.0F - 1.0F));
         }
      }

      stepSize = featureSize;
      double scale = 1.0 / (double)w;
      double scaleMod = 1.0;

      do {
         int halfStep = stepSize / 2;

         int y;
         int x;
         double a;
         double b;
         double c;
         double d;
         double e;
         for(y = 0; y < w; y += stepSize) {
            for(x = 0; x < w; x += stepSize) {
               a = this.sample(x, y);
               b = this.sample(x + stepSize, y);
               c = this.sample(x, y + stepSize);
               d = this.sample(x + stepSize, y + stepSize);
               e = (a + b + c + d) / 4.0 + (double)((random.nextFloat() * 2.0F - 1.0F) * (float)stepSize) * scale;
               this.setSample(x + halfStep, y + halfStep, e);
            }
         }

         for(y = 0; y < w; y += stepSize) {
            for(x = 0; x < w; x += stepSize) {
               a = this.sample(x, y);
               b = this.sample(x + stepSize, y);
               c = this.sample(x, y + stepSize);
               d = this.sample(x + halfStep, y + halfStep);
               e = this.sample(x + halfStep, y - halfStep);
               double f = this.sample(x - halfStep, y + halfStep);
               double H = (a + b + d + e) / 4.0 + (double)((random.nextFloat() * 2.0F - 1.0F) * (float)stepSize) * scale * 0.5;
               double g = (a + c + d + f) / 4.0 + (double)((random.nextFloat() * 2.0F - 1.0F) * (float)stepSize) * scale * 0.5;
               this.setSample(x + halfStep, y, H);
               this.setSample(x, y + halfStep, g);
            }
         }

         stepSize /= 2;
         scale *= scaleMod + 0.8;
         scaleMod *= 0.3;
      } while(stepSize > 1);

   }

   private double sample(int x, int y) {
      return this.values[(x & this.w - 1) + (y & this.h - 1) * this.w];
   }

   private void setSample(int x, int y, double value) {
      this.values[(x & this.w - 1) + (y & this.h - 1) * this.w] = value;
   }

   public static byte[][] createAndValidateTopMap(int w, int h) {
      byte[][] result;
      int[] count;
      do {
         result = createTopMap(w, h);
         count = new int[256];

         for(int i = 0; i < w * h; ++i) {
            ++count[result[0][i] & 255];
         }
      } while(count[Tile.rock.id & 255] < 100 || count[Tile.sand.id & 255] < 100 || count[Tile.grass.id & 255] < 100 || count[Tile.tree.id & 255] < 100 || count[Tile.stairsDown.id & 255] < 2);

      return result;
   }

   public static byte[][] createAndValidateUndergroundMap(int w, int h, int depth) {
      byte[][] result;
      int[] count;
      do {
         do {
            do {
               do {
                  result = createUndergroundMap(w, h, depth);
                  count = new int[256];

                  for(int i = 0; i < w * h; ++i) {
                     ++count[result[0][i] & 255];
                  }
               } while(count[Tile.rock.id & 255] < 100);
            } while(count[Tile.dirt.id & 255] < 100);
         } while(count[(Tile.ironOre.id & 255) + depth - 1] < 20);
      } while(depth < 3 && count[Tile.stairsDown.id & 255] < 2);

      return result;
   }

   public static byte[][] createAndValidateSkyMap(int w, int h) {
      byte[][] result;
      int[] count;
      do {
         result = createSkyMap(w, h);
         count = new int[256];

         for(int i = 0; i < w * h; ++i) {
            ++count[result[0][i] & 255];
         }
      } while(count[Tile.cloud.id & 255] < 2000 || count[Tile.stairsDown.id & 255] < 2);

      return result;
   }

   private static byte[][] createTopMap(int w, int h) {
      LevelGen mnoise1 = new LevelGen(w, h, 16);
      LevelGen mnoise2 = new LevelGen(w, h, 16);
      LevelGen mnoise3 = new LevelGen(w, h, 16);
      LevelGen noise1 = new LevelGen(w, h, 32);
      LevelGen noise2 = new LevelGen(w, h, 32);
      byte[] map = new byte[w * h];
      byte[] data = new byte[w * h];

      int count;
      int i;
      int x;
      for(count = 0; count < h; ++count) {
         for(i = 0; i < w; ++i) {
            x = i + count * w;
            double val = Math.abs(noise1.values[x] - noise2.values[x]) * 3.0 - 2.0;
            double mval = Math.abs(mnoise1.values[x] - mnoise2.values[x]);
            mval = Math.abs(mval - mnoise3.values[x]) * 3.0 - 2.0;
            double xd = (double)i / ((double)w - 1.0) * 2.0 - 1.0;
            double yd = (double)count / ((double)h - 1.0) * 2.0 - 1.0;
            if (xd < 0.0) {
               xd = -xd;
            }

            if (yd < 0.0) {
               yd = -yd;
            }

            double dist = xd >= yd ? xd : yd;
            dist = dist * dist * dist * dist;
            dist = dist * dist * dist * dist;
            val = val + 1.0 - dist * 20.0;
            if (val < -0.5) {
               map[x] = Tile.water.id;
            } else if (val > 0.5 && mval < -1.5) {
               map[x] = Tile.rock.id;
            } else {
               map[x] = Tile.grass.id;
            }
         }
      }

      int y;
      for(count = 0; count < w * h / 2800; ++count) {
         i = random.nextInt(w);
         x = random.nextInt(h);

         for(y = 0; y < 10; ++y) {
            int yyStart = i + random.nextInt(21) - 10;
            int xxStart = x + random.nextInt(21) - 10;

            for(int loop = 0; loop < 100; ++loop) {
               int xo = yyStart + random.nextInt(5) - random.nextInt(5);
               int yo = xxStart + random.nextInt(5) - random.nextInt(5);

               for(int yy = yo - 1; yy <= yo + 1; ++yy) {
                  for(int xx = xo - 1; xx <= xo + 1; ++xx) {
                     if (xx >= 0 && yy >= 0 && xx < w && yy < h && map[xx + yy * w] == Tile.grass.id) {
                        map[xx + yy * w] = Tile.sand.id;
                     }
                  }
               }
            }
         }
      }

      for(count = 0; count < w * h / 400; ++count) {
         i = random.nextInt(w);
         x = random.nextInt(h);

         for(y = 0; y < 200; ++y) {
            int yy = i + random.nextInt(15) - random.nextInt(15);
            int xx = x + random.nextInt(15) - random.nextInt(15);
            if (yy >= 0 && xx >= 0 && yy < w && xx < h && map[yy + xx * w] == Tile.grass.id) {
               map[yy + xx * w] = Tile.tree.id;
            }
         }
      }

      for(count = 0; count < w * h / 400; ++count) {
         i = random.nextInt(w);
         x = random.nextInt(h);
         y = random.nextInt(4);

         for(int yy = 0; yy < 30; ++yy) {
            int xx = i + random.nextInt(5) - random.nextInt(5);
            int yyPos = x + random.nextInt(5) - random.nextInt(5);
            if (xx >= 0 && yyPos >= 0 && xx < w && yyPos < h && map[xx + yyPos * w] == Tile.grass.id) {
               map[xx + yyPos * w] = Tile.flower.id;
               data[xx + yyPos * w] = (byte)(y + random.nextInt(4) * 16);
            }
         }
      }

      for(count = 0; count < w * h / 100; ++count) {
         i = random.nextInt(w);
         x = random.nextInt(h);
         if (i >= 0 && x >= 0 && i < w && x < h && map[i + x * w] == Tile.sand.id) {
            map[i + x * w] = Tile.cactus.id;
         }
      }

      count = 0;

      label133:
      for(i = 0; i < w * h / 100; ++i) {
         x = random.nextInt(w - 2) + 1;
         y = random.nextInt(h - 2) + 1;

         for(int yy = y - 1; yy <= y + 1; ++yy) {
            for(int xx = x - 1; xx <= x + 1; ++xx) {
               if (map[xx + yy * w] != Tile.rock.id) {
                  continue label133;
               }
            }
         }

         map[x + y * w] = Tile.stairsDown.id;
         ++count;
         if (count == 4) {
            break;
         }
      }

      return new byte[][]{map, data};
   }

   private static byte[][] createUndergroundMap(int w, int h, int depth) {
      LevelGen mnoise1 = new LevelGen(w, h, 16);
      LevelGen mnoise2 = new LevelGen(w, h, 16);
      LevelGen mnoise3 = new LevelGen(w, h, 16);
      LevelGen nnoise1 = new LevelGen(w, h, 16);
      LevelGen nnoise2 = new LevelGen(w, h, 16);
      LevelGen nnoise3 = new LevelGen(w, h, 16);
      LevelGen wnoise1 = new LevelGen(w, h, 16);
      LevelGen wnoise2 = new LevelGen(w, h, 16);
      LevelGen wnoise3 = new LevelGen(w, h, 16);
      LevelGen noise1 = new LevelGen(w, h, 32);
      LevelGen noise2 = new LevelGen(w, h, 32);
      byte[] map = new byte[w * h];
      byte[] data = new byte[w * h];

      int count;
      int i;
      int x;
      for(count = 0; count < h; ++count) {
         for(i = 0; i < w; ++i) {
            x = i + count * w;
            double val = Math.abs(noise1.values[x] - noise2.values[x]) * 3.0 - 2.0;
            double mval = Math.abs(mnoise1.values[x] - mnoise2.values[x]);
            mval = Math.abs(mval - mnoise3.values[x]) * 3.0 - 2.0;
            double nval = Math.abs(nnoise1.values[x] - nnoise2.values[x]);
            nval = Math.abs(nval - nnoise3.values[x]) * 3.0 - 2.0;
            double wval = Math.abs(wnoise1.values[x] - wnoise2.values[x]);
            wval = Math.abs(nval - wnoise3.values[x]) * 3.0 - 2.0;
            double xd = (double)i / ((double)w - 1.0) * 2.0 - 1.0;
            double yd = (double)count / ((double)h - 1.0) * 2.0 - 1.0;
            if (xd < 0.0) {
               xd = -xd;
            }

            if (yd < 0.0) {
               yd = -yd;
            }

            double dist = xd >= yd ? xd : yd;
            dist = dist * dist * dist * dist;
            dist = dist * dist * dist * dist;
            val = val + 1.0 - dist * 20.0;
            if (val > -2.0 && wval < -2.0 + (double)(depth / 2 * 3)) {
               if (depth > 2) {
                  map[x] = Tile.lava.id;
               } else {
                  map[x] = Tile.water.id;
               }
            } else if (!(val > -2.0) || !(mval < -1.7) && !(nval < -1.4)) {
               map[x] = Tile.rock.id;
            } else {
               map[x] = Tile.dirt.id;
            }
         }
      }

      int r = 2;

      int y;
      for(i = 0; i < w * h / 400; ++i) {
         x = random.nextInt(w);
         y = random.nextInt(h);

         for(int yy = 0; yy < 30; ++yy) {
            int xx = x + random.nextInt(5) - random.nextInt(5);
            int yyPos = y + random.nextInt(5) - random.nextInt(5);
            if (xx >= r && yyPos >= r && xx < w - r && yyPos < h - r && map[xx + yyPos * w] == Tile.rock.id) {
               map[xx + yyPos * w] = (byte)((Tile.ironOre.id & 255) + depth - 1);
            }
         }
      }

      if (depth < 3) {
         count = 0;

         label81:
         for(i = 0; i < w * h / 100; ++i) {
            x = random.nextInt(w - 20) + 10;
            y = random.nextInt(h - 20) + 10;

            for(int yy = y - 1; yy <= y + 1; ++yy) {
               for(int xx = x - 1; xx <= x + 1; ++xx) {
                  if (map[xx + yy * w] != Tile.rock.id) {
                     continue label81;
                  }
               }
            }

            map[x + y * w] = Tile.stairsDown.id;
            ++count;
            if (count == 4) {
               break;
            }
         }
      }

      return new byte[][]{map, data};
   }

   private static byte[][] createSkyMap(int w, int h) {
      LevelGen noise1 = new LevelGen(w, h, 8);
      LevelGen noise2 = new LevelGen(w, h, 8);
      byte[] map = new byte[w * h];
      byte[] data = new byte[w * h];

      int count;
      for(count = 0; count < h; ++count) {
         for(int xPos = 0; xPos < w; ++xPos) {
            int index = xPos + count * w;
            double val = Math.abs(noise1.values[index] - noise2.values[index]) * 3.0 - 2.0;
            double xd = (double)xPos / ((double)w - 1.0) * 2.0 - 1.0;
            double yd = (double)count / ((double)h - 1.0) * 2.0 - 1.0;
            if (xd < 0.0) {
               xd = -xd;
            }

            if (yd < 0.0) {
               yd = -yd;
            }

            double dist = xd >= yd ? xd : yd;
            dist = dist * dist * dist * dist;
            dist = dist * dist * dist * dist;
            val = -val * 1.0 - 2.2;
            val = val + 1.0 - dist * 20.0;
            if (val < -0.25) {
               map[index] = Tile.infiniteFall.id;
            } else {
               map[index] = Tile.cloud.id;
            }
         }
      }

      label89:
      for(count = 0; count < w * h / 50; ++count) {
         int x = random.nextInt(w - 2) + 1;
         int y = random.nextInt(h - 2) + 1;

         for(int yy = y - 1; yy <= y + 1; ++yy) {
            for(int xx = x - 1; xx <= x + 1; ++xx) {
               if (map[xx + yy * w] != Tile.cloud.id) {
                  continue label89;
               }
            }
         }

         map[x + y * w] = Tile.cloudCactus.id;
      }

      count = 0;

      label70:
      for(int loop = 0; loop < w * h; ++loop) {
         int x = random.nextInt(w - 2) + 1;
         int y = random.nextInt(h - 2) + 1;

         for(int yy = y - 1; yy <= y + 1; ++yy) {
            for(int xx = x - 1; xx <= x + 1; ++xx) {
               if (map[xx + yy * w] != Tile.cloud.id) {
                  continue label70;
               }
            }
         }

         map[x + y * w] = Tile.stairsDown.id;
         ++count;
         if (count == 2) {
            break;
         }
      }

      return new byte[][]{map, data};
   }

   public static void main(String[] args) {
      int d = 0;

      while(true) {
         int w = 128;
         int h = 128;
         byte[] map = createAndValidateSkyMap(w, h)[0];
         BufferedImage img = new BufferedImage(w, h, 1);
         int[] pixels = new int[w * h];

         for(int y = 0; y < h; ++y) {
            for(int x = 0; x < w; ++x) {
               int i = x + y * w;
               if (map[i] == Tile.water.id) {
                  pixels[i] = 128;
               }

               if (map[i] == Tile.grass.id) {
                  pixels[i] = 2129952;
               }

               if (map[i] == Tile.rock.id) {
                  pixels[i] = 10526880;
               }

               if (map[i] == Tile.dirt.id) {
                  pixels[i] = 6307904;
               }

               if (map[i] == Tile.sand.id) {
                  pixels[i] = 10526784;
               }

               if (map[i] == Tile.tree.id) {
                  pixels[i] = 12288;
               }

               if (map[i] == Tile.lava.id) {
                  pixels[i] = 16719904;
               }

               if (map[i] == Tile.cloud.id) {
                  pixels[i] = 10526880;
               }

               if (map[i] == Tile.stairsDown.id) {
                  pixels[i] = 16777215;
               }

               if (map[i] == Tile.stairsUp.id) {
                  pixels[i] = 16777215;
               }

               if (map[i] == Tile.cloudCactus.id) {
                  pixels[i] = 16711935;
               }
            }
         }

         img.setRGB(0, 0, w, h, pixels, 0, w);
         JOptionPane.showMessageDialog((Component)null, (Object)null, "Another", 0, new ImageIcon(img.getScaledInstance(w * 4, h * 4, 16)));
      }
   }
}
