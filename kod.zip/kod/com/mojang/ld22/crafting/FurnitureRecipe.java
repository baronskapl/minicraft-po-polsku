package com.mojang.ld22.crafting;

import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.FurnitureItem;
import java.lang.reflect.InvocationTargetException;

public class FurnitureRecipe extends Recipe {
   private Class<? extends Furniture> clazz;

   public FurnitureRecipe(Class<? extends Furniture> clazz) throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
      super(new FurnitureItem(clazz.getDeclaredConstructor().newInstance()));
      this.clazz = clazz;
   }

   public void craft(Player player) {
      try {
         player.inventory.add(0, new FurnitureItem(this.clazz.getDeclaredConstructor().newInstance()));
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }
}
