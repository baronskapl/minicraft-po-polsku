package com.mojang.ld22;

import java.applet.Applet;
import java.awt.BorderLayout;

@SuppressWarnings({"deprecation", "removal"})
public class GameApplet extends Applet {
   private static final long serialVersionUID = 1L;
   private Game game = new Game();

   public void init() {
      this.setLayout(new BorderLayout());
      this.add(this.game, "Center");
   }

   public void start() {
      this.game.start();
   }

   public void stop() {
      this.game.stop();
   }
}
