package com.mojang.ld22.sound;

import java.applet.Applet;
import java.applet.AudioClip;

@SuppressWarnings({"deprecation", "removal"})
public class Sound {
   public static final Sound playerHurt = new Sound("/playerhurt.wav");
   public static final Sound playerDeath = new Sound("/death.wav");
   public static final Sound monsterHurt = new Sound("/monsterhurt.wav");
   public static final Sound test = new Sound("/test.wav");
   public static final Sound pickup = new Sound("/pickup.wav");
   public static final Sound bossdeath = new Sound("/bossdeath.wav");
   public static final Sound craft = new Sound("/craft.wav");
   private AudioClip clip;

   private Sound(String name) {
      try {
         this.clip = Applet.newAudioClip(Sound.class.getResource(name));
      } catch (Throwable var3) {
         var3.printStackTrace();
      }

   }

   public void play() {
      try {
         (new Thread() {
            public void run() {
               Sound.this.clip.play();
            }
         }).start();
      } catch (Throwable var2) {
         var2.printStackTrace();
      }

   }
}
