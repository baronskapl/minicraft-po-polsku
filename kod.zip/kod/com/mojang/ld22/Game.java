package com.mojang.ld22;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.gfx.SpriteSheet;
import com.mojang.ld22.i18n.Lang;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.screen.DeadMenu;
import com.mojang.ld22.screen.LevelTransitionMenu;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.TitleMenu;
import com.mojang.ld22.screen.WonMenu;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class Game extends Canvas implements Runnable {
   private static final long serialVersionUID = 1L;
   private Random random = new Random();
   public static final String NAME = "Minicraft";
   public static final int HEIGHT = 160;
   public static final int WIDTH = 240;
   private static final int SCALE = 4;
   private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
   private int[] pixels;
   private boolean running;
   private Screen screen;
   private Screen lightScreen;
   private InputHandler input;
   private int[] colors;
   private int tickCount;
   public int gameTime;
   private Level level;
   private Level[] levels;
   private int currentLevel;
   public Player player;
   public Menu menu;
   private int playerDeadTime;
   private int pendingLevelChange;
   private int wonTimer;
   public boolean hasWon;

   public Game() {
      this.pixels = ((DataBufferInt)this.image.getRaster().getDataBuffer()).getData();
      this.running = false;
      this.input = new InputHandler(this);
      this.colors = new int[256];
      this.tickCount = 0;
      this.gameTime = 0;
      this.levels = new Level[5];
      this.currentLevel = 3;
      this.wonTimer = 0;
      this.hasWon = false;
   }

   public void setMenu(Menu menu) {
      this.menu = menu;
      if (menu != null) {
         menu.init(this, this.input);
      }

   }

   public void start() {
      this.running = true;
      (new Thread(this)).start();
   }

   public void stop() {
      this.running = false;
   }

   public void resetGame() {
      this.playerDeadTime = 0;
      this.wonTimer = 0;
      this.gameTime = 0;
      this.hasWon = false;
      this.levels = new Level[5];
      this.currentLevel = 3;
      this.levels[4] = new Level(128, 128, 1, (Level)null);
      this.levels[3] = new Level(128, 128, 0, this.levels[4]);
      this.levels[2] = new Level(128, 128, -1, this.levels[3]);
      this.levels[1] = new Level(128, 128, -2, this.levels[2]);
      this.levels[0] = new Level(128, 128, -3, this.levels[1]);
      this.level = this.levels[this.currentLevel];
      this.player = new Player(this, this.input);
      this.player.findStartPos(this.level);
      this.level.add(this.player);

      for(int i = 0; i < 5; ++i) {
         this.levels[i].trySpawn(5000);
      }

   }

   private void init() {
      int pp = 0;

      for(int r = 0; r < 6; ++r) {
         for(int g = 0; g < 6; ++g) {
            for(int b = 0; b < 6; ++b) {
               int rr = r * 255 / 5;
               int gg = g * 255 / 5;
               int bb = b * 255 / 5;
               int mid = (rr * 30 + gg * 59 + bb * 11) / 100;
               int r1 = (rr + mid * 1) / 2 * 230 / 255 + 10;
               int g1 = (gg + mid * 1) / 2 * 230 / 255 + 10;
               int b1 = (bb + mid * 1) / 2 * 230 / 255 + 10;
               this.colors[pp++] = r1 << 16 | g1 << 8 | b1;
            }
         }
      }

      try {
         SpriteSheet spriteSheet = new SpriteSheet(ImageIO.read(Game.class.getResourceAsStream("/icons.png")));
         this.screen = new Screen(WIDTH, HEIGHT, spriteSheet);
         this.lightScreen = new Screen(WIDTH, HEIGHT, spriteSheet);
      } catch (IOException var12) {
         var12.printStackTrace();
      }

      this.resetGame();
      this.setMenu(new TitleMenu());
   }

   public void run() {
      long lastTime = System.nanoTime();
      double unprocessed = 0.0;
      double nsPerTick = 1.6666666666666666E7;
      int frames = 0;
      int ticks = 0;
      long lastTimer1 = System.currentTimeMillis();
      this.init();

      while(this.running) {
         long now = System.nanoTime();
         unprocessed += (double)(now - lastTime) / nsPerTick;
         lastTime = now;

         boolean shouldRender;
         for(shouldRender = true; unprocessed >= 1.0; shouldRender = true) {
            ++ticks;
            this.tick();
            --unprocessed;
         }

         try {
            Thread.sleep(2L);
         } catch (InterruptedException var15) {
            var15.printStackTrace();
         }

         if (shouldRender) {
            ++frames;
            this.render();
         }

         if (System.currentTimeMillis() - lastTimer1 > 1000L) {
            lastTimer1 += 1000L;
            System.out.println(ticks + " ticks, " + frames + " fps");
            frames = 0;
            ticks = 0;
         }
      }

   }

   public void tick() {
      ++this.tickCount;
      if (!this.hasFocus()) {
         this.input.releaseAll();
      } else {
         if (!this.player.removed && !this.hasWon) {
            ++this.gameTime;
         }

         this.input.tick();
         if (this.menu != null) {
            this.menu.tick();
         } else {
            if (this.player.removed) {
               ++this.playerDeadTime;
               if (this.playerDeadTime > 60) {
                  this.setMenu(new DeadMenu());
               }
            } else if (this.pendingLevelChange != 0) {
               this.setMenu(new LevelTransitionMenu(this.pendingLevelChange));
               this.pendingLevelChange = 0;
            }

            if (this.wonTimer > 0 && --this.wonTimer == 0) {
               this.setMenu(new WonMenu());
            }

            this.level.tick();
            ++Tile.tickCount;
         }
      }

   }

   public void changeLevel(int dir) {
      this.level.remove(this.player);
      this.currentLevel += dir;
      this.level = this.levels[this.currentLevel];
      this.player.x = (this.player.x >> 4) * 16 + 8;
      this.player.y = (this.player.y >> 4) * 16 + 8;
      this.level.add(this.player);
   }

   public void render() {
      BufferStrategy bs = this.getBufferStrategy();
      if (bs == null) {
         this.createBufferStrategy(3);
         this.requestFocus();
      } else {
         int xScroll = this.player.x - this.screen.w / 2;
         int yScroll = this.player.y - (this.screen.h - 8) / 2;
         if (xScroll < 16) {
            xScroll = 16;
         }

         if (yScroll < 16) {
            yScroll = 16;
         }

         if (xScroll > this.level.w * 16 - this.screen.w - 16) {
            xScroll = this.level.w * 16 - this.screen.w - 16;
         }

         if (yScroll > this.level.h * 16 - this.screen.h - 16) {
            yScroll = this.level.h * 16 - this.screen.h - 16;
         }

         int y;
         int x;
         int cc;
         if (this.currentLevel > 3) {
            y = Color.get(20, 20, 121, 121);

            for(x = 0; x < (this.screen.h + 7) / 8; ++x) {
               for(cc = 0; cc < (this.screen.w + 7) / 8; ++cc) {
                  this.screen.render(cc * 8 - (xScroll / 4 & 7), x * 8 - (yScroll / 4 & 7), 0, y, 0);
               }
            }
         }

         this.level.renderBackground(this.screen, xScroll, yScroll);
         this.level.renderSprites(this.screen, xScroll, yScroll);
         if (this.currentLevel < 3) {
            this.lightScreen.clear(0);
            this.level.renderLight(this.lightScreen, xScroll, yScroll);
            this.screen.overlay(this.lightScreen, xScroll, yScroll);
         }

         this.renderGui();
         if (!this.hasFocus()) {
            this.renderFocusNagger();
         }

         for(y = 0; y < this.screen.h; ++y) {
            for(x = 0; x < this.screen.w; ++x) {
               cc = this.screen.pixels[x + y * this.screen.w];
               if (cc < 255) {
                  this.pixels[x + y * WIDTH] = this.colors[cc];
               }
            }
         }

         Graphics g = bs.getDrawGraphics();
         g.fillRect(0, 0, this.getWidth(), this.getHeight());
         int ww = WIDTH * SCALE;
         int hh = HEIGHT * SCALE;
         int xo = (this.getWidth() - ww) / 2;
         int yo = (this.getHeight() - hh) / 2;
         g.drawImage(this.image, xo, yo, ww, hh, (ImageObserver)null);
         g.dispose();
         bs.show();
      }
   }

   private void renderGui() {
      int i;
      int hudX = (this.screen.w - 160) / 2;
      for(i = 0; i < 2; ++i) {
         for(int x = 0; x < 20; ++x) {
            this.screen.render(hudX + x * 8, this.screen.h - 16 + i * 8, 384, Color.get(0, 0, 0, 0), 0);
         }
      }

      for(i = 0; i < 10; ++i) {
         if (i < this.player.health) {
            this.screen.render(hudX + i * 8, this.screen.h - 16, 384, Color.get(0, 200, 500, 533), 0);
         } else {
            this.screen.render(hudX + i * 8, this.screen.h - 16, 384, Color.get(0, 100, 0, 0), 0);
         }

         if (this.player.staminaRechargeDelay > 0) {
            if (this.player.staminaRechargeDelay / 4 % 2 == 0) {
               this.screen.render(hudX + i * 8, this.screen.h - 8, 385, Color.get(0, 555, 0, 0), 0);
            } else {
               this.screen.render(hudX + i * 8, this.screen.h - 8, 385, Color.get(0, 110, 0, 0), 0);
            }
         } else if (i < this.player.stamina) {
            this.screen.render(hudX + i * 8, this.screen.h - 8, 385, Color.get(0, 220, 550, 553), 0);
         } else {
            this.screen.render(hudX + i * 8, this.screen.h - 8, 385, Color.get(0, 110, 0, 0), 0);
         }
      }

      if (this.player.activeItem != null) {
         this.player.activeItem.renderInventory(this.screen, this.screen.w / 2, this.screen.h - 16);
      }

      if (this.menu != null) {
         this.menu.render(this.screen);
      }

   }

   private void renderFocusNagger() {
      String msg = Lang.get("menu.click_to_focus");
      int xx = (this.screen.w - msg.length() * 8) / 2;
      int yy = (this.screen.h - 8) / 2;
      int w = msg.length();
      int h = 1;
      this.screen.render(xx - 8, yy - 8, 416, Color.get(-1, 1, 5, 445), 0);
      this.screen.render(xx + w * 8, yy - 8, 416, Color.get(-1, 1, 5, 445), 1);
      this.screen.render(xx - 8, yy + 8, 416, Color.get(-1, 1, 5, 445), 2);
      this.screen.render(xx + w * 8, yy + 8, 416, Color.get(-1, 1, 5, 445), 3);

      int y;
      for(y = 0; y < w; ++y) {
         this.screen.render(xx + y * 8, yy - 8, 417, Color.get(-1, 1, 5, 445), 0);
         this.screen.render(xx + y * 8, yy + 8, 417, Color.get(-1, 1, 5, 445), 2);
      }

      for(y = 0; y < h; ++y) {
         this.screen.render(xx - 8, yy + y * 8, 418, Color.get(-1, 1, 5, 445), 0);
         this.screen.render(xx + w * 8, yy + y * 8, 418, Color.get(-1, 1, 5, 445), 1);
      }

      if (this.tickCount / 20 % 2 == 0) {
         Font.draw(msg, this.screen, xx, yy, Color.get(5, 333, 333, 333));
      } else {
         Font.draw(msg, this.screen, xx, yy, Color.get(5, 555, 555, 555));
      }

   }

   public void scheduleLevelChange(int dir) {
      this.pendingLevelChange = dir;
   }

   public static void main(String[] args) {
      Game game = new Game();
      game.setMinimumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
      game.setMaximumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
      game.setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
      JFrame frame = new JFrame("Minicraft");
      frame.setDefaultCloseOperation(3);
      frame.setLayout(new BorderLayout());
      try {
         frame.setIconImage(ImageIO.read(Game.class.getResource("/app-icon.png")));
      } catch (IOException e) {
         e.printStackTrace();
      }
      frame.add(game, "Center");
      frame.pack();
      frame.setResizable(false);
      frame.setLocationRelativeTo((Component)null);
      frame.setVisible(true);
      game.start();
   }

   public void won() {
      this.wonTimer = 180;
      this.hasWon = true;
   }
}
