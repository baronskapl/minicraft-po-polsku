package com.mojang.ld22.gfx;

public class Font {
   private static final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ      0123456789.,!?'\"-+=/\\%()<>:;     ";

   public static void draw(String msg, Screen screen, int x, int y, int col) {
      if (msg == null) {
         return;
      }

      msg = normalize(msg);
      for(int i = 0; i < msg.length(); ++i) {
         int ix = chars.indexOf(msg.charAt(i));
         if (ix >= 0) {
            screen.render(x + i * 8, y, ix + 960, col, 0);
         }
      }
   }

   private static String normalize(String msg) {
      StringBuilder sb = new StringBuilder();
      for(int i = 0; i < msg.length(); ++i) {
         char c = msg.charAt(i);
         switch (c) {
            case '\u0105': case '\u0104': sb.append('A'); break;
            case '\u0107': case '\u0106': sb.append('C'); break;
            case '\u0119': case '\u0118': sb.append('E'); break;
            case '\u0142': case '\u0141': sb.append('L'); break;
            case '\u0144': case '\u0143': sb.append('N'); break;
            case '\u00F3': case '\u00D3': sb.append('O'); break;
            case '\u015B': case '\u015A': sb.append('S'); break;
            case '\u017A': case '\u0179': case '\u017C': case '\u017B': sb.append('Z'); break;
            default: sb.append(Character.toUpperCase(c)); break;
         }
      }
      return sb.toString();
   }

   public static void renderFrame(Screen screen, String title, int x0, int y0, int x1, int y1) {
      for(int y = y0; y <= y1; ++y) {
         for(int x = x0; x <= x1; ++x) {
            if (x == x0 && y == y0) {
               screen.render(x * 8, y * 8, 416, Color.get(-1, 1, 5, 445), 0);
            } else if (x == x1 && y == y0) {
               screen.render(x * 8, y * 8, 416, Color.get(-1, 1, 5, 445), 1);
            } else if (x == x0 && y == y1) {
               screen.render(x * 8, y * 8, 416, Color.get(-1, 1, 5, 445), 2);
            } else if (x == x1 && y == y1) {
               screen.render(x * 8, y * 8, 416, Color.get(-1, 1, 5, 445), 3);
            } else if (y == y0) {
               screen.render(x * 8, y * 8, 417, Color.get(-1, 1, 5, 445), 0);
            } else if (y == y1) {
               screen.render(x * 8, y * 8, 417, Color.get(-1, 1, 5, 445), 2);
            } else if (x == x0) {
               screen.render(x * 8, y * 8, 418, Color.get(-1, 1, 5, 445), 0);
            } else if (x == x1) {
               screen.render(x * 8, y * 8, 418, Color.get(-1, 1, 5, 445), 1);
            } else {
               screen.render(x * 8, y * 8, 418, Color.get(5, 5, 5, 5), 1);
            }
         }
      }

      draw(title, screen, x0 * 8 + 8, y0 * 8, Color.get(5, 5, 5, 550));
   }
}
