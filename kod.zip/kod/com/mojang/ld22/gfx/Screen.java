package com.mojang.ld22.gfx;

public class Screen {
   public int xOffset;
   public int yOffset;
   public static final int BIT_MIRROR_X = 1;
   public static final int BIT_MIRROR_Y = 2;
   public final int w;
   public final int h;
   public int[] pixels;
   private SpriteSheet sheet;
   private int[] dither = new int[]{0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

   public Screen(int w, int h, SpriteSheet sheet) {
      this.sheet = sheet;
      this.w = w;
      this.h = h;
      this.pixels = new int[w * h];
   }

   public void clear(int color) {
      for(int i = 0; i < this.pixels.length; ++i) {
         this.pixels[i] = color;
      }

   }

   public void render(int xp, int yp, int tile, int colors, int bits) {
      xp -= this.xOffset;
      yp -= this.yOffset;
      boolean mirrorX = (bits & 1) > 0;
      boolean mirrorY = (bits & 2) > 0;
      int xTile = tile % 32;
      int yTile = tile / 32;
      int toffs = xTile * 8 + yTile * 8 * this.sheet.width;

      for(int y = 0; y < 8; ++y) {
         int ys = y;
         if (mirrorY) {
            ys = 7 - y;
         }

         if (y + yp >= 0 && y + yp < this.h) {
            for(int x = 0; x < 8; ++x) {
               if (x + xp >= 0 && x + xp < this.w) {
                  int xs = x;
                  if (mirrorX) {
                     xs = 7 - x;
                  }

                  int col = colors >> this.sheet.pixels[xs + ys * this.sheet.width + toffs] * 8 & 255;
                  if (col < 255) {
                     this.pixels[x + xp + (y + yp) * this.w] = col;
                  }
               }
            }
         }
      }

   }

   public void setOffset(int xOffset, int yOffset) {
      this.xOffset = xOffset;
      this.yOffset = yOffset;
   }

   public void overlay(Screen screen2, int xa, int ya) {
      int[] oPixels = screen2.pixels;
      int i = 0;

      for(int y = 0; y < this.h; ++y) {
         for(int x = 0; x < this.w; ++x) {
            if (oPixels[i] / 10 <= this.dither[(x + xa & 3) + (y + ya & 3) * 4]) {
               this.pixels[i] = 0;
            }

            ++i;
         }
      }

   }

   public void renderLight(int x, int y, int r) {
      x -= this.xOffset;
      y -= this.yOffset;
      int x0 = x - r;
      int x1 = x + r;
      int y0 = y - r;
      int y1 = y + r;
      if (x0 < 0) {
         x0 = 0;
      }

      if (y0 < 0) {
         y0 = 0;
      }

      if (x1 > this.w) {
         x1 = this.w;
      }

      if (y1 > this.h) {
         y1 = this.h;
      }

      for(int yy = y0; yy < y1; ++yy) {
         int yd = yy - y;
         yd *= yd;

         for(int xx = x0; xx < x1; ++xx) {
            int xd = xx - x;
            int dist = xd * xd + yd;
            if (dist <= r * r) {
               int br = 255 - dist * 255 / (r * r);
               if (this.pixels[xx + yy * this.w] < br) {
                  this.pixels[xx + yy * this.w] = br;
               }
            }
         }
      }

   }
}
